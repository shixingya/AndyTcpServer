#include "AndyReceiver.h"
#include "ui_AndyReceiver.h"

const quint16 PORT = 3333;
const qint64 LOADBYTES = 4 * 1024; // 4 kilo-byte
const int DATA_STREAM_VERSION = QDataStream::Qt_4_8;
AndyReceiver::AndyReceiver(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AndyReceiver)
{
    ui->setupUi(this);

    server = new QTcpServer(this);
    /* 连接请求 -> 接受连接 */
    connect(server, SIGNAL(newConnection()), this, SLOT(accept_connect()));
    if(!server->listen(QHostAddress::Any, PORT))
    {
        qDebug() << "*** Listen to Port Failed ***" ;
        qDebug() << server->errorString();
    }
}

AndyReceiver::~AndyReceiver()
{
    delete ui;

    SafeDelete(server);
}

void AndyReceiver::on_pushButton_2_clicked()
{
    QString dir =QFileDialog::getExistingDirectory(this, tr("Open Directory"), "C:/", QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

    dir.append("/");
    dir.replace("/","\\");
    qDebug()<<"本地接收数据存档为："<<dir;
    receiveDir= dir;
}
/*--- 接受连接请求 ---*/
void AndyReceiver::accept_connect()
{
    qDebug()<<"接受连接请求 00000"<<endl;
    AndyProgressBar *bar =new AndyProgressBar();
    bar->SetMaxRange(100);
    bar->UpdateProgress(0);
    ui->vl_content->addWidget(bar);

    Receiver * receiver =new Receiver;
    receiver->setReceive(server->nextPendingConnection());
    receiver->setReceiveSaveDir(receiveDir);
    connect(receiver,SIGNAL(UpdateText(QString)),bar,SLOT(on_UpdateText(QString)));
    connect(receiver,SIGNAL(UpdateMaximum(int)),bar,SLOT(on_UpdateMaximum(int)));
    connect(receiver,SIGNAL(UpdatePercent(int)),bar,SLOT(on_UpdatePercent(int)));
    receiverList.push_back(receiver);
}


/*--- 接收文件 ---*/
void Receiver::recevie_file()
{
    qDebug()<<"receive_file();"<<sender();
    QDataStream in(receive);
    in.setVersion(DATA_STREAM_VERSION);


    /* 首部未接收/未接收完 */
    if(receive_gotBytes <= 2 * sizeof(qint64))
    {
        if(!receive_nameSize) // 前两个长度字段未接收
        {
            if(receive->bytesAvailable() >= 2 * sizeof(qint64))
            {
                in >> receive_fileBytes >> receive_nameSize;
                receive_gotBytes += 2 * sizeof(qint64);
                emit UpdateMaximum(receive_fileBytes);
                emit UpdatePercent(receive_gotBytes);
            }
            else // 数据不足，等下次
            {
                qDebug()<<" 数据不足文件名长度，等下次 Errir 044";
                return;
            }
        }
        else if(receive->bytesAvailable() > receive_nameSize)
        {
            in >> receive_fileName;
            receive_gotBytes += receive_nameSize;
            emit UpdatePercent(receive_gotBytes);
            qDebug()<< "--- File Name: "
                    << receive_fileName;
        }
        else // 数据不足文件名长度，等下次
        {
            qDebug()<<" 数据不足文件名长度，等下次 Errir 046";
            return;
        }
    }

    /* 已读文件名、文件未打开 -> 尝试打开文件 */
    if(!receive_fileName.isEmpty() && receive_file == Q_NULLPTR)
    {
        QString saveFilePath =_saveDir.append(receive_fileName);
        receive_file = new QFile(saveFilePath);
        if(!receive_file->open(QFile::WriteOnly)) // 打开失败
        {
            qDebug() << "*** File Open Failed ***"  ;
            SafeDelete(receive_file);
            return;
        }
        emit UpdateText(QString("文件%1打开成功!").arg(saveFilePath)) ;
    }
    if(receive_file == Q_NULLPTR) // 文件未打开，不能进行后续操作
        return;

    if(receive_gotBytes < receive_fileBytes) // 文件未接收完
    {
        receive_gotBytes += receive->bytesAvailable();
        emit UpdatePercent(receive_gotBytes);
        receive_file->write(receive->readAll());
    }
    if(receive_gotBytes == receive_fileBytes) // 文件接收完
    {
        receive->close(); // 关socket
        receive_file->close(); // 关文件
        SafeDelete(receive_file);
        emit UpdatePercent(receive_gotBytes);
        emit UpdateText("文件接收完成!") ;
    }
}

/*--- 出错处理 ---*/
void Receiver::receive_error(QAbstractSocket::SocketError)
{
    qDebug()  << "*** Socket Error ***"   << receive->errorString();
    receive->close(); // 关cocket
    SafeDelete(receive);
    SafeDelete(receive_file);
    receive_fileName.clear(); // 清空文件名
    receive_fileBytes = receive_gotBytes = receive_nameSize = 0;
    emit UpdateText("接收数据失败!") ;
}
void Receiver::setReceive(QTcpSocket * tcpSocket)
{
    qDebug()<<"tcpSocket is "<<tcpSocket<<endl;
    receive =tcpSocket;
    /* 有数据到 -> 接受数据 */
    connect(receive, SIGNAL(readyRead()), this, SLOT(recevie_file()));
    /* socket出错 -> 出错处理 */
    connect(receive, SIGNAL(error(QAbstractSocket::SocketError)),
            this, SLOT(receive_error(QAbstractSocket::SocketError)));
    emit UpdateText("开始接收数据!") ;
    receive_gotBytes=0;
}
