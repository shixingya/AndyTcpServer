#pragma once
#include "preheader.h"
#include "./QProgressIndicator/AndyProgressBar.h"
#include "./TaskManager.h"
namespace Ui {
class AndyReceiver;
}

class Receiver: public QObject
{
    Q_OBJECT
public:
    Receiver(){}
    ~Receiver()
    {

        SafeDelete(receive);
    }

    void setReceiveSaveDir(QString dir){_saveDir =dir;}
    void setReceive(QTcpSocket * tcpSocket);
private slots:
    void recevie_file();
    void receive_error(QAbstractSocket::SocketError);

signals:
    void UpdateText(QString);
    void UpdateMaximum(int);
    void UpdatePercent(int) ;
private:
    QString _saveDir ="D:\\";
    QTcpSocket *receive=nullptr;
    QString receive_fileName="";
    QFile *receive_file=nullptr;
    /* 已接受数据，总数据，文件名长度 */
    qint64 receive_gotBytes=0, receive_fileBytes=0, receive_nameSize=0;
};

class AndyReceiver : public QWidget
{
    Q_OBJECT

public:
    explicit AndyReceiver(QWidget *parent = 0);
    ~AndyReceiver();

private slots:
    void on_pushButton_2_clicked();
    void accept_connect();

private:
    Ui::AndyReceiver *ui;
    QTcpServer *server=nullptr;
    QString receiveDir ="D:\\";

    QList<Receiver *> receiverList;
};
