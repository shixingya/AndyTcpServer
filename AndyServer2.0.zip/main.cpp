#include "mainwindow.h"
#include <QApplication>

QString _saveDir ="D:\\";
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}
